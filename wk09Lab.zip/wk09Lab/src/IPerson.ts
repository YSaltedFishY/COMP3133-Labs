//IPerson.ts
//Interface - blueprint for a class
export interface IPerson {
    firstName: String
    lastName: String

    showDetails(): void

    // showInfo(): void
}