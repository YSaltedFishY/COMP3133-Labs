import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-list',
  imports: [],
  templateUrl: './post-list.component.html',
  styleUrl: './post-list.component.css'
})

export class PostListComponent{
  public posts: any[] = [];
  isClassAvailable = true

}

