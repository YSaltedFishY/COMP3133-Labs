import { Component } from '@angular/core';

@Component({
  selector: 'app-reactive-form',
  standalone: true,
  imports: [],
  templateUrl: './reactive-form.component.html',
  styleUrl: './reactive-form.component.css'
})

export class ReactiveFormComponent {
  userForm: any;

  submitForm(): void {
    if (this.userForm?.valid) {
      console.log('Form data:', this.userForm.value);
    }
  }
}
